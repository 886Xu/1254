package com.watabou.towngenerator.ui;

import openfl.display.BitmapData;
import openfl.display.Bitmap;
import openfl.display.Sprite;
import openfl.events.MouseEvent;
import openfl.text.TextField;
import openfl.text.TextFormat;
import openfl.text.TextFieldAutoSize;

import com.watabou.towngenerator.mapping.CityMap;

using com.watabou.utils.DisplayObjectExtender;

class Tooltip extends Sprite {

	public static var instance : Tooltip;

	public function new() {
		instance = this;

		super();

		this.onActivate( activation );

		set( null );
	}

	private function activation( active:Bool )
		if (active) {
			stage.addEventListener( MouseEvent.MOUSE_MOVE, onMouseMove );
			stage.addEventListener( MouseEvent.MOUSE_DOWN, onMouseMove );
		} else {
			stage.removeEventListener( MouseEvent.MOUSE_MOVE, onMouseMove );
			stage.removeEventListener( MouseEvent.MOUSE_DOWN, onMouseMove );
		}

	private function onMouseMove( e:MouseEvent ) {
		x = parent.mouseX + 4;
		y = parent.mouseY;
		e.updateAfterEvent();
	}

	public function set( txt:String ) {
		visible = (txt != null);
		if (visible) {
			// 清除旧的提示内容
			while (numChildren > 0) removeChildAt(0);

			// 创建系统字体文本
			var tf = new TextField();
			tf.text = txt;
			var format = new TextFormat("sans-serif", 13, CityMap.palette.paper);
			tf.defaultTextFormat = format;
			tf.setTextFormat(format);
			tf.autoSize = TextFieldAutoSize.LEFT;
			tf.x = 4;
			tf.y = 2;
			tf.mouseEnabled = false;

			// 创建深色背景
			var bg = new Bitmap(new BitmapData(Std.int(tf.width + 8), Std.int(tf.height + 4), false, CityMap.palette.dark));
			addChild(bg);
			addChild(tf);
		}
	}
}