package com.watabou.towngenerator.ui;

import openfl.display.Sprite;
import openfl.text.TextField;
import openfl.text.TextFormat;
import openfl.text.TextFieldAutoSize;
import openfl.events.MouseEvent;
import com.watabou.towngenerator.mapping.CityMap;

using com.watabou.utils.DisplayObjectExtender;

class Tooltip extends Sprite {

	public static var instance : Tooltip;
	private var textField : TextField;

	public function new() {
		instance = this;
		super();

		textField = new TextField();
		textField.autoSize = TextFieldAutoSize.LEFT;
		textField.selectable = false;
		textField.mouseEnabled = false;
		textField.background = true;
		textField.backgroundColor = CityMap.palette.dark;
		
		// 设置字体颜色为背景色（因为原版是反转色）
		textField.textColor = CityMap.palette.paper;
		var format = new TextFormat("sans-serif", 12);
		textField.defaultTextFormat = format;

		addChild(textField);

		this.onActivate( activation );

		set( null );
	}

	private function activation( active:Bool )
		if (active) {
			stage.addEventListener( MouseEvent.MOUSE_MOVE, onMouseMove );
			stage.addEventListener( MouseEvent.MOUSE_DOWN, onMouseMove );
		} else {
			stage.removeEventListener( MouseEvent.MOUSE_MOVE, onMouseMove );
			stage.removeEventListener( MouseEvent.MOUSE_DOWN, onMouseMove );
		}

	private function onMouseMove( e:MouseEvent ) {
		x = parent.mouseX + 4;
		y = parent.mouseY;
		e.updateAfterEvent();
	}

	public function set( txt:String ) {
		visible = (txt != null);
		if (visible) {
			textField.text = txt;
			// 动态调整底框大小
			textField.width = textField.textWidth + 6;
			textField.height = textField.textHeight + 4;
		}
	}
}