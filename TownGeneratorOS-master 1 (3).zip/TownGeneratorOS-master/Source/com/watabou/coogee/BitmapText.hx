package com.watabou.coogee;

import openfl.display.Sprite;
import openfl.text.TextField;
import openfl.text.TextFormat;
import openfl.text.TextFieldAutoSize;
import openfl.geom.ColorTransform;
import openfl.geom.Point;
import openfl.geom.Rectangle;
import openfl.utils.AssetType;
import openfl.Assets;

/**
 * 重写后的文本类，完全使用原生 TextField，完美支持中文
 */
class BitmapText extends TextField {

	public var _font	: BitmapFont;
	public var _text	: String = "";

	public function new( font:BitmapFont, text:String="" ) {
		super();

		_font = font;
		_text = text;
		
		this.selectable = false;
		this.multiline = false;
		this.wordWrap = false;
		this.autoSize = TextFieldAutoSize.LEFT;

		// 默认中文字体设置
		var format = new TextFormat("Microsoft YaHei, Arial, sans-serif", 12, 0x333333);
		this.defaultTextFormat = format;

		// 注意：这里把原来的 text() 方法改名为 setText()，避免和 TextField 自带的 text 属性冲突
		setText(text);
	}

	public function setText( value:String ):Void {
		_text = value;
		this.text = value;
	}

	public function font( value:BitmapFont ):Void {
		_font = value;
	}

	public function baseLine():Int {
		return 15; // 给一个默认基线
	}

	// 保留原版的静态方法，防止其他文件调用报错
	public static function split( font:BitmapFont, text:String, width:Int ):Array<BitmapText> {
		return [new BitmapText(font, text)];
	}
}

/**
 * 为了兼容原项目的代码，保留这个空的字体类
 */
class BitmapFont {
	public static var LATIN_FULL : String = "";
	public var bitmapData	: openfl.display.BitmapData;
	public var table	: Map<String, Rectangle> = new Map();
	public var letterSpacing	: Int = 0;
	public var baseLine			: Int = 0;
	public var lineHeight		: Int = 0;

	public function new( src:String, chars:String=null ) {}

	public static function get( id:String, color:Int=0xffffffff ):BitmapFont {
		return new BitmapFont("");
	}
}