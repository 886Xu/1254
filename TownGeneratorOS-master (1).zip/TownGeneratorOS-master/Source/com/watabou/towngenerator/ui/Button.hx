package com.watabou.towngenerator.ui;

import openfl.display.Sprite;
import openfl.display.Bitmap;
import openfl.display.BitmapData;
import openfl.events.MouseEvent;
import openfl.text.TextField;
import openfl.text.TextFormat;
import openfl.text.TextFormatAlign;

import msignal.Signal.Signal0;

import com.watabou.towngenerator.mapping.CityMap;

class Button extends Sprite {

	// 增大按钮尺寸以容纳中文字符
	private static inline var WIDTH		= 70;
	private static inline var HEIGHT	= 18;

	public var click	: Signal0 = new Signal0();

	public function new( label:String ) {
		super();

		// 绘制深色背景
		var bg = new Bitmap(new BitmapData( WIDTH, HEIGHT, false, CityMap.palette.dark ));
		addChild( bg );

		// 添加系统字体文本（不再使用图片字库）
		var tf = new TextField();
		tf.text = label;
		var format = new TextFormat("sans-serif", 13, CityMap.palette.paper);
		tf.defaultTextFormat = format;
		tf.setTextFormat(format);
		tf.width = WIDTH;
		tf.textAlign = TextFormatAlign.CENTER;
		tf.y = (HEIGHT - 18) / 2; // 垂直居中
		tf.mouseEnabled = false;
		addChild( tf );

		buttonMode = true;
		addEventListener( MouseEvent.MOUSE_DOWN, onClickHandler );
	}

	private function onClickHandler( e:MouseEvent ) click.dispatch();
}