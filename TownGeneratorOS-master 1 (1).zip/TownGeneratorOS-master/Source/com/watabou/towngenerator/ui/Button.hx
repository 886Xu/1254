package com.watabou.towngenerator.ui;

import openfl.display.Sprite;
import openfl.events.MouseEvent;
import openfl.text.TextField;
import openfl.text.TextFormat;
import openfl.text.TextFormatAlign;

import msignal.Signal.Signal0;
import com.watabou.towngenerator.mapping.CityMap;

class Button extends Sprite {

	private static inline var WIDTH		= 45;
	private static inline var HEIGHT	= 13;

	public var click	: Signal0 = new Signal0();

	public function new( label:String ) {
		super();

		// 改用 TextField 支持中文
		var textField = new TextField();
		textField.text = label;
		textField.width = WIDTH;
		textField.height = HEIGHT;
		textField.selectable = false;
		textField.multiline = false;
		textField.wordWrap = false;
		
		var format = new TextFormat("Arial", 12, CityMap.palette.dark);
		format.align = TextFormatAlign.CENTER; 
		textField.defaultTextFormat = format;

		this.graphics.beginFill(CityMap.palette.light); 
		this.graphics.drawRect(0, 0, WIDTH, HEIGHT);
		this.graphics.endFill();

		addChild( textField );

		buttonMode = true;
		addEventListener( MouseEvent.MOUSE_DOWN, onClickHandler );
	}

	private function onClickHandler( e:MouseEvent ) click.dispatch();
}