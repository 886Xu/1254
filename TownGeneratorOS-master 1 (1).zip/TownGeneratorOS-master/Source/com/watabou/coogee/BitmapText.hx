package com.watabou.coogee;

import openfl.text.TextField;
import openfl.text.TextFormat;
import openfl.text.TextFieldAutoSize;

class BitmapText extends TextField {

	public function new( font:Dynamic, text:String="" ) {
		super();
		
		// 设置默认中文字体
		var format = new TextFormat("Microsoft YaHei, Arial, sans-serif", 12, 0x333333);
		this.defaultTextFormat = format;
		this.text = text;
		this.autoSize = TextFieldAutoSize.LEFT;
	}

	public function text( value:String ):Void {
		this.text = value;
	}

	public function font( value:Dynamic ):Void {
		// 忽略原版的字体设置，保持系统字体
	}

	public var baseLine(get, never) : Int;
	private function get_baseLine():Int {
		return 15; // 调整文字的基线
	}
}

class BitmapFont {
	// 这里留空，因为我们已经不用位图字体了
}